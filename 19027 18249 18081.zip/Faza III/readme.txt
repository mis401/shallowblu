Aplikacija se pokrece pokretanjem drawing.py 
Nas git repozitorijum: https://github.com/mis401/shallowblu